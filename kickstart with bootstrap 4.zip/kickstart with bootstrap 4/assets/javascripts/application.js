$(document).ready(function() {
  window.console.log("Mae govannen mellon!");
});